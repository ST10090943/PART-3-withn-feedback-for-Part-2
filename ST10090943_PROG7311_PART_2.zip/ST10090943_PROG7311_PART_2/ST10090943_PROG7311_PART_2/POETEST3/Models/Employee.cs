﻿namespace POETEST3.Models
{
    public class Employee
    {
        public int Id { get; set; }
        public string EmpName { get; set; }
        public string EmpSurname { get; set; }
        public string EmpUsername { get; set; }
        public string EmpPassword { get; set; }
    }
}
