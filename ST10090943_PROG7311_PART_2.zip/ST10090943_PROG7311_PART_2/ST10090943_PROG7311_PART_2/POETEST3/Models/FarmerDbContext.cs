﻿using Microsoft.EntityFrameworkCore;

namespace POETEST3.Models
{
    public class FarmerDbContext : DbContext
    {
        public DbSet<Farmer> Farmers { get; set; }

        public FarmerDbContext(DbContextOptions<FarmerDbContext> options)
            :base(options)
        {
                
        }
    }
}
