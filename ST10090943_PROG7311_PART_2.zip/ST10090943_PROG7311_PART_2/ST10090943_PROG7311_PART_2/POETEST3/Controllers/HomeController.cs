using Microsoft.AspNetCore.Mvc;
using POETEST3.Models;
using System.Diagnostics;
using Microsoft.AspNetCore.Http;
using System.Linq;


namespace POETEST3.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        private readonly FarmerDbContext _farmercontext;
        private readonly ProductsDbContext _productcontext;
        private readonly EmployeeDbContext _employeecontext;

        public HomeController(ILogger<HomeController> logger, FarmerDbContext FarmerContext, ProductsDbContext ProductContext, EmployeeDbContext employeecontext)
        {
            _logger = logger;
            _farmercontext = FarmerContext;
            _productcontext = ProductContext;
            _employeecontext = employeecontext;
        }

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult LoginFarmer(string username, string password)
        {
            // Check if the credentials exist in the database
            var farmer = _farmercontext.Farmers.FirstOrDefault(f => f.Username == username && f.Password == password);

            if (farmer != null)
            {
                // Store the farmer's name in TempData
                TempData["FarmerName"] = $"{farmer.Name} {farmer.Surname}";

                // Credentials are correct, redirect to FarmerHomePage
                return RedirectToAction("FarmerHomePage");
            }
            else
            {
                // Credentials are incorrect, show error message or redirect back to login page
                ViewBag.ErrorMessage = "Invalid credentials. Please try again.";
                return View("LoginFarmer");
            }
        }

        public IActionResult ViewProducts(string nameFilter, string categoryFilter, DateTime? dateFilter)
        {
            // Retrieve all products from the database
            var allProducts = _productcontext.Products.ToList();

            // Apply filtering if any filter parameters are provided
            if (!string.IsNullOrEmpty(nameFilter))
            {
                allProducts = allProducts.Where(p => p.Name.ToLower().Contains(nameFilter.ToLower())).ToList();
            }
            if (!string.IsNullOrEmpty(categoryFilter))
            {
                allProducts = allProducts.Where(p => p.Category.ToLower().Contains(categoryFilter.ToLower())).ToList();
            }

            return View(allProducts);
        }

        public IActionResult CreateFarmer()
        {
            return View();
        }
        public IActionResult CreateFarmerForm(Farmer model)
        {
            _farmercontext.Farmers.Add(model);
            _farmercontext.SaveChanges();
            return RedirectToAction("EmployeeHomePage");
        }
        public IActionResult CreateEmployeeForm(Employee model)
        {
            _employeecontext.Employees.Add(model);
            _employeecontext.SaveChanges();
            return RedirectToAction("LoginEmployee");
        }
        public IActionResult CreateProduct()
        {
            return View();
        }
        public IActionResult CreateProductForm(Product model)
        {
            _productcontext.Products.Add(model);
            _productcontext.SaveChanges();
            return RedirectToAction("FarmerHomePage");
        }
        public IActionResult FarmerHomePage()
        {
            // Retrieve the farmer's name from TempData
            var farmerName = TempData["FarmerName"] as string;
            ViewBag.FarmerName = farmerName;

            return View();
        }

        public IActionResult EmployeeHomePage()
        {
            // Retrieve the employee's name from TempData
            var employeeName = TempData["EmployeeName"] as string;

            // Check if employeeName is null or empty
            if (!string.IsNullOrEmpty(employeeName))
            {
                ViewBag.EmployeeName = employeeName;
            }
            else
            {
                // Set a default value or handle the situation accordingly
                ViewBag.EmployeeName = "Employee";
            }

            return View();
        }


        public IActionResult LoginEmployee(string EmpUsername, string EmpPassword)
        {
            // Check if the credentials exist in the database
            var employee = _employeecontext.Employees.FirstOrDefault(e => e.EmpUsername == EmpUsername && e.EmpPassword == EmpPassword);

            if (employee != null)
            {
                // Store the employee's name in TempData
                TempData["EmployeeName"] = $"{employee.EmpName} {employee.EmpSurname}";

                // Credentials are correct, redirect to EmployeeHomePage
                return RedirectToAction("EmployeeHomePage");
            }
            else
            {
                // Credentials are incorrect, show error message or redirect back to login page
                ViewBag.ErrorMessage = "Invalid credentials. Please try again.";
                return View("LoginEmployee");
            }
        }


        public IActionResult CreateEmployee(Employee employee)
        {
            if (ModelState.IsValid)
            {
                // Add the employee to the database
                _employeecontext.Employees.Add(employee);
                _employeecontext.SaveChanges();

                // Redirect back to the login screen
                return RedirectToAction("LoginEmployee");
            }

            // If the model state is not valid, return the create employee view with validation errors
            return View("CreateEmployee", employee);
        }


        public IActionResult Products()
        {
            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
